using RimWorld;
using Verse;

namespace RaiseTheRoof
{
	[DefOf]
	public static class ThingDefOf
	{
        public static ThingDef RTR_SteelRoof;
        public static ThingDef RTR_RemoveSteelRoof;
    }
}
