using RimWorld;
using Verse;

namespace RaiseTheRoof
{
	[DefOf]
	public static class RoofDefOf
	{
		public static RoofDef RTR_RoofSteel;
	}
}
