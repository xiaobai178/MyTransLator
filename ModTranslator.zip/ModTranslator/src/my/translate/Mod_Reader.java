package my.translate;
import java.io.File;
import java.util.ArrayList;


public class Mod_Reader {
	public String mod_path;
	public String mod_name;
	public String mod_author;
	public String mod_targetVersion;
	public String mod_description;
	public int language_num;
	public ArrayList<String> language_list;//���԰��б�
	//public int XML_num;
	//public ArrayList<XML_Reader> XML_list;//���԰���ȫ��XML�ļ�
	public int flag;//״̬ 0=��ʼ��ʧ�� 1=����
	public Mod_Reader(String mod_path){
		this.mod_path=mod_path;
		mod_name="";
		mod_author="";
		mod_targetVersion="";
		mod_description="";
		language_num=0;
		language_list=new ArrayList<String>();
		flag=1;
		
		File dir_mod=new File(mod_path);
		if(!dir_mod.exists()) flag=0;
		
		File file_about=new File(mod_path+File.separator+"About"+File.separator+"About.xml");
		if(!file_about.exists()) {
			flag=0;
		}else {
			mod_name=XML_Reader.AboutInfo(file_about,"name");
			mod_author=XML_Reader.AboutInfo(file_about,"author");
			mod_targetVersion=XML_Reader.AboutInfo(file_about,"targetVersion");
			if(mod_targetVersion.startsWith("Error"))
				mod_targetVersion=XML_Reader.AboutInfo(file_about,"supportedVersions");
			mod_description=XML_Reader.AboutInfo(file_about,"description");
		}
		
		File dir_language=new File(mod_path+File.separator+"Languages");
		if(dir_language.exists()) language_num=1;//��ָ����
		
		//XML_list=new ArrayList<XML_Reader>();
		//XML_num=0;
		if(language_num==1){
			language_num=0;
			File[] lans=dir_language.listFiles();
			for(File f:lans){
				if(f.isDirectory()) {
					language_list.add(f.getName());
					language_num++;
					//all_XML(f);
				}
			}
		}else {
			flag=0;
		}
	}
	/*private void all_XML(File dir){//����ĳ�����ļ�������XML�ļ�
		if(!dir.exists()) return;
		if(dir.isFile()) return;
		File[] fs=dir.listFiles();
		for(File f:fs){
			if(f.isDirectory()){
				all_XML(f);
			}else if(f.isFile()&&f.getName().toLowerCase().endsWith(".xml")){
				XML_list.add(new XML_Reader(f.getAbsolutePath()));
				XML_num++;
			}
		}
	}*/
	public String getInfo() {
		StringBuilder str=new StringBuilder();
		//str.append("State= "+flag+" (0=error)\n");
		str.append("Name= "+mod_name+"\n");
		str.append("Author= "+mod_author+"\n");
		str.append("Path= "+mod_path+"\n");
		str.append("Version= "+mod_targetVersion+"\n");
		str.append("Language= ");
		for(int i=0;i<language_num;i++) {
			str.append(language_list.get(i)+" ");
		}
		str.append("\nDescription= "+mod_description+"\n\n");
		return str.toString();
	}
	
}
