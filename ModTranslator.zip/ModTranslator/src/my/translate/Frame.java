package my.translate;
import java.awt.EventQueue;
import java.awt.HeadlessException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.filechooser.FileFilter;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeNode;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JRadioButton;
import java.awt.event.ActionListener;
import java.io.File;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Frame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JScrollPane scrollPane,scrollPane_2;//tree,table
	private JTextArea textArea,textArea_1,textArea_2,textArea_3;
	private JTree tree;
	private JTable table;
	private JTextField textField;//��ǰ������XML�ļ�
	private JTextField textField_1;//���·��
	
	private String PATH;//��·��
	private String OUTPUT;//���·��
	private XML_Reader XML;//��ǰ������XML�ļ�
	private int API;//����API 1=Baidu 2=google 3=Youdao 4=Bing
	private int Line;//ѡ�еı�ǩ��
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Frame frame = new Frame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Frame() {
		setResizable(false);
		setTitle("MyTranslator");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 680);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnFile = new JMenu("File");
		menuBar.add(mnFile);
		
		JMenuItem mntmmod = new JMenuItem("Open Mod Dir...");
		mnFile.add(mntmmod);
		
		JMenuItem mntmxml = new JMenuItem("Open XML File...");
		mnFile.add(mntmxml);
		
		JSeparator separator = new JSeparator();
		mnFile.add(separator);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("Close");
		mnFile.add(mntmNewMenuItem);
		
		JSeparator separator_2 = new JSeparator();
		mnFile.add(separator_2);
		
		JMenuItem mntmSave = new JMenuItem("Save");
		mnFile.add(mntmSave);
		
		JMenuItem mntmSaveAs = new JMenuItem("Save As...");
		mnFile.add(mntmSaveAs);
		
		JSeparator separator_1 = new JSeparator();
		mnFile.add(separator_1);
		
		JMenuItem mntmRefresh = new JMenuItem("Refresh");
		mnFile.add(mntmRefresh);
		
		JSeparator separator_3 = new JSeparator();
		mnFile.add(separator_3);
		
		JMenuItem mntmExit = new JMenuItem("Exit");
		mnFile.add(mntmExit);
		
		JMenu mnSelection = new JMenu("Option");
		menuBar.add(mnSelection);
		
		JMenuItem mntmSetOutputDir = new JMenuItem("Set Output Dir...");
		mnSelection.add(mntmSetOutputDir);
		
		JMenu mnHelp = new JMenu("Help");
		menuBar.add(mnHelp);
		
		JMenuItem mntmHelp = new JMenuItem("Help");
		mnHelp.add(mntmHelp);
		
		JMenuItem mntmAbout = new JMenuItem("About");
		mnHelp.add(mntmAbout);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(5, 5, 285, 360);
		contentPane.add(scrollPane);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(5, 375, 285, 210);
		contentPane.add(scrollPane_1);	
		
		textArea = new JTextArea();
		textArea.setEditable(false);
		scrollPane_1.setViewportView(textArea);
		
		scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(300, 5, 694, 255);
		contentPane.add(scrollPane_2);
		
		JScrollPane scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(300, 265, 555, 100);
		contentPane.add(scrollPane_3);
		
		textArea_1 = new JTextArea();
		textArea_1.setEditable(false);
		scrollPane_3.setViewportView(textArea_1);
		
		JScrollPane scrollPane_4 = new JScrollPane();
		scrollPane_4.setBounds(300, 375, 555, 100);
		contentPane.add(scrollPane_4);
		
		textArea_2 = new JTextArea();
		textArea_2.setEditable(false);
		scrollPane_4.setViewportView(textArea_2);
		
		JScrollPane scrollPane_5 = new JScrollPane();
		scrollPane_5.setBounds(300, 485, 555, 100);
		contentPane.add(scrollPane_5);
		
		textArea_3 = new JTextArea();
		scrollPane_5.setViewportView(textArea_3);
		
		JButton btnTrans = new JButton("Trans");
		btnTrans.setBounds(865, 469, 73, 23);
		contentPane.add(btnTrans);
		
		JRadioButton rdbtnBaidu = new JRadioButton("Baidu");
		rdbtnBaidu.setSelected(true);
		rdbtnBaidu.setBounds(865, 350, 73, 23);
		contentPane.add(rdbtnBaidu);
		
		JRadioButton rdbtnGoogle = new JRadioButton("Google");
		rdbtnGoogle.setBounds(865, 370, 73, 23);
		contentPane.add(rdbtnGoogle);
		
		JRadioButton rdbtnYoudao = new JRadioButton("Youdao");
		rdbtnYoudao.setBounds(865, 390, 73, 23);
		contentPane.add(rdbtnYoudao);
		
		JRadioButton rdbtnBing = new JRadioButton("Bing");
		rdbtnBing.setBounds(865, 410, 73, 23);
		contentPane.add(rdbtnBing);
		
		JButton btnCopy = new JButton("Copy");
		btnCopy.setBounds(865, 502, 73, 23);
		contentPane.add(btnCopy);
		
		JButton btnApply = new JButton("Apply");
		btnApply.setBounds(865, 562, 73, 23);
		contentPane.add(btnApply);
		
		JButton btnBrowser = new JButton("Browser");
		btnBrowser.setBounds(880, 434, 91, 23);
		contentPane.add(btnBrowser);
		
		JButton btnOpen = new JButton("Open Original");
		btnOpen.setBounds(865, 270, 120, 23);
		contentPane.add(btnOpen);
		
		JButton btnOpenTrans = new JButton("Open Trans");
		btnOpenTrans.setBounds(865, 303, 120, 23);
		contentPane.add(btnOpenTrans);
		
		textField = new JTextField();
		textField.setEditable(false);
		textField.setBounds(5, 595, 480, 25);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setEditable(false);
		textField_1.setColumns(10);
		textField_1.setBounds(505, 595, 480, 25);
		contentPane.add(textField_1);
		
		//�¼�
		rdbtnBaidu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {//Baidu��ť����
				rdbtnGoogle.setSelected(false);
				rdbtnYoudao.setSelected(false);
				rdbtnBing.setSelected(false);
				API=1;
			}
		});
		rdbtnGoogle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {//Google��ť����
				rdbtnBaidu.setSelected(false);
				rdbtnYoudao.setSelected(false);
				rdbtnBing.setSelected(false);
				API=2;
			}
		});
		rdbtnYoudao.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {//Youdao��ť����
				rdbtnGoogle.setSelected(false);
				rdbtnBaidu.setSelected(false);
				rdbtnBing.setSelected(false);
				API=3;
			}
		});
		rdbtnBing.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {//Bing��ť����
				rdbtnGoogle.setSelected(false);
				rdbtnYoudao.setSelected(false);
				rdbtnBaidu.setSelected(false);
				API=4;
			}
		});
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {//close,�رմ�����
				OUTPUT="";
				XML=null;
				Line=-1;
				refresh("",null);
				textArea.setText("");
			}
		});
		mntmRefresh.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {//ˢ������
				refresh(PATH,XML);
			}
		});
		mntmmod.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {//��mod�ļ���
				JFileChooser fDialog = new JFileChooser(File.listRoots()[0].getAbsolutePath());//ϵͳ��һ����Ŀ¼
				fDialog.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);//ֻ��ѡ��Ŀ¼
				fDialog.setDialogTitle("Open Mod dir...");
				try {
					int returnVal= fDialog.showOpenDialog(null);
					if (JFileChooser.APPROVE_OPTION == returnVal) {// �����ѡ�����ļ�
						PATH = fDialog.getSelectedFile().getAbsolutePath();
						OUTPUT = PATH+File.separator+"TransDir";
						refresh(PATH,null);
						Mod_Reader mod=new Mod_Reader(PATH);
						textArea.setText(mod.getInfo());
					} 
				} catch (HeadlessException e) {
					textArea.setText("Error:Open Mod dir failed!");
				}
			}
		});
		mntmxml.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {//��XML�ļ�
				JFileChooser fDialog = new JFileChooser(File.listRoots()[0].getAbsolutePath());//ϵͳ��һ����Ŀ¼
				fDialog.setFileFilter(new ImageFilter());
				fDialog.setDialogTitle("Open XML file...");
				try {
					int returnVal= fDialog.showOpenDialog(null);
					if (JFileChooser.APPROVE_OPTION == returnVal) {// �����ѡ�����ļ�
						PATH = fDialog.getSelectedFile().getAbsolutePath();
						OUTPUT = fDialog.getSelectedFile().getParent()+File.separator+"TransDir";
						refresh(PATH,new XML_Reader(PATH));
						textArea.setText(XML.getInfo());
					} 
				} catch (HeadlessException e) {
					textArea.setText("Error:Open XML file failed!");
				}
			}
		});
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		mntmHelp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JOptionPane.showMessageDialog(null,"No help,just do it", "Help",
						JOptionPane.INFORMATION_MESSAGE);
			}
		});
		mntmAbout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JOptionPane.showMessageDialog(null,"Author: Hefei\nVersion��0.1.201908", "About",
						JOptionPane.INFORMATION_MESSAGE);
			}
		});
		mntmSetOutputDir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {//��output�ļ���
				JFileChooser fDialog = new JFileChooser(File.listRoots()[0].getAbsolutePath());//ϵͳ��һ����Ŀ¼
				fDialog.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);//ֻ��ѡ��Ŀ¼
				fDialog.setDialogTitle("Select output dir...");
				try {
					int returnVal= fDialog.showOpenDialog(null);
					if (JFileChooser.APPROVE_OPTION == returnVal) {// �����ѡ�����ļ�
						OUTPUT = fDialog.getSelectedFile().getAbsolutePath();
						textField_1.setText("To= "+OUTPUT);
						//refresh(PATH,XML);
					} 
				} catch (HeadlessException e) {
					textArea.setText("Error:Select output dir failed!");
				}
			}
		});
		mntmSave.addActionListener(new ActionListener() {//���浽OUTPUT
			public void actionPerformed(ActionEvent arg0) {
				if(XML==null||OUTPUT.equals("")) {
					JOptionPane.showMessageDialog(null,"XML or output_dir is null", "Save failed",JOptionPane.ERROR_MESSAGE);
					return;
				}
				if(XML.saveXML(OUTPUT+File.separator+XML.filename))
					JOptionPane.showMessageDialog(null,"Save successfully", "Save successfully",JOptionPane.INFORMATION_MESSAGE);
				else
					JOptionPane.showMessageDialog(null,"Save failed", "Save failed",JOptionPane.ERROR_MESSAGE);
			}
		});
		mntmSaveAs.addActionListener(new ActionListener() {//����Ϊ
			public void actionPerformed(ActionEvent arg0) {
				if(XML==null) {
					JOptionPane.showMessageDialog(null,"No XML can be saved", "Save failed",JOptionPane.ERROR_MESSAGE);
					return;
				}
				JFileChooser fDialog = new JFileChooser(File.listRoots()[0].getAbsolutePath());//ϵͳ��һ����Ŀ¼
				fDialog.setDialogTitle("Save as...");
				fDialog.setFileFilter(new ImageFilter());
				try {
					int returnVal= fDialog.showOpenDialog(null);
					if (JFileChooser.APPROVE_OPTION == returnVal) {// �����ѡ�����ļ�
						String savePath=fDialog.getSelectedFile().getAbsolutePath();
						if(savePath.indexOf('.')==-1) savePath+=".xml";
						if(XML.saveXML(savePath))
							JOptionPane.showMessageDialog(null,"Save successfully", "Save successfully",JOptionPane.INFORMATION_MESSAGE);
						else
							JOptionPane.showMessageDialog(null,"Save failed", "Save failed",JOptionPane.ERROR_MESSAGE);
					} 
				} catch (HeadlessException e) {
					JOptionPane.showMessageDialog(null,"Save failed", "Save failed",JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnBrowser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {//�����
				Translator_API.getWeb(API,textArea_1.getText().trim());
			}
		});
		btnOpen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {//��ԴĿ¼
				if(PATH.equals("")) return;
				try{
		            Runtime.getRuntime().exec("explorer.exe /e,"+PATH);
		        }catch(Exception e){}
			}
		});
		btnOpenTrans.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {//��Ŀ��Ŀ¼
				if(OUTPUT.equals("")) return;
				try{
		            Runtime.getRuntime().exec("explorer.exe /e,"+OUTPUT);
		        }catch(Exception e){}
			}
		});
		btnTrans.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String str=textArea_1.getText().trim();
				if(str.equals("")) return;
				textArea_2.setText(Translator_API.getResult(API, str));
			}
		});
		btnCopy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textArea_3.setText(textArea_2.getText().trim());
			}
		});
		btnApply.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {//������ı���������д��doc����
				if(XML==null) return;
				if(XML.setTagText(Line, textArea_3.getText().trim())==false)
					JOptionPane.showMessageDialog(null,"Value not changed", "Apply failed",JOptionPane.ERROR_MESSAGE);;
				refresh(XML);
			}
		});
		
		//��ʼ��
		OUTPUT="";
		refresh("",null);
		API=1;
		Line=-1;
	}
	
	
	private void all_XML(File dir,DefaultMutableTreeNode dir_node){//�����ļ�������XML�ļ�
		if(!dir.exists()) return;
		if(dir.isFile()) return;
		File[] fs=dir.listFiles();
		for(File f:fs){
			if(f.isDirectory()){
				DefaultMutableTreeNode node= new DefaultMutableTreeNode(f.getName());
				dir_node.add(node);
				all_XML(f,node);
			}else if(f.isFile()&&f.getName().toLowerCase().endsWith(".xml")){
				DefaultMutableTreeNode node= new DefaultMutableTreeNode(f.getName());
				dir_node.add(node);
			}
		}
	}
	private void refresh(String path,XML_Reader xml) {//����PATH,XML.����������,��,����ı���
		PATH=path;
		XML=xml;
		refresh(xml);//���±�
		
		if(OUTPUT.equals(""))
			textField_1.setText("To= no dir be selected");
		else
			textField_1.setText("To= "+OUTPUT);
		
		if(PATH.equals("")) {
			scrollPane.setViewportView(null);
		}else {
			DefaultMutableTreeNode root= new DefaultMutableTreeNode(PATH);
			all_XML(new File(PATH),root);
			tree = new JTree(root);
			scrollPane.setViewportView(tree);
			tree.addTreeSelectionListener(new TreeSelectionListener() {
				public void valueChanged(TreeSelectionEvent evt) {
					DefaultMutableTreeNode node = (DefaultMutableTreeNode)tree.getLastSelectedPathComponent();// ��ȡѡ�нڵ�
					String name = node.toString();// ѡ�нڵ���
					TreeNode t=node.getParent();// ѡ�нڵ�ĸ��ڵ���
					while(t!=null) {
						name=t.toString()+File.separator+name;
						t=t.getParent();
					}
					if(name.toLowerCase().endsWith(".xml"))
						refresh(new XML_Reader(name));
				}
			});
		}
		
		textArea_1.setText("");
		textArea_2.setText("");
		textArea_3.setText("");
	}
	private void refresh(XML_Reader xml) {//����XML.���±�,xml_info
		XML=xml;
		if(xml==null) {
			textField.setText("From= no XML file be selected");
			table=new JTable();
			table.setModel(new DefaultTableModel(
					null,
					new String[] {"No","State", "Tag_Name","Tag_Text"}
					));
			scrollPane_2.setViewportView(table);
		}else {
			textField.setText("From= "+XML.path_a);
			String[][] tag=new String[xml.Tag_Num][4];
			for(int i=0;i<xml.Tag_Num;i++) {
				tag[i][0]=""+(i+1);
				if(xml.Tag_state.get(i)==false)
					tag[i][1]="Unchanged";
				else
					tag[i][1]="Modified";
				tag[i][2]=xml.Tag_Name.get(i);
				tag[i][3]=xml.Tag_Text.get(i);
			}
			table=new JTable();
			table.setModel(new DefaultTableModel(
					tag,
					new String[] {"No","State", "Tag_Name","Tag_Text"}
					));
			table.getColumnModel().getColumn(0).setPreferredWidth(5);//�����п��ٷֱ�
			table.getColumnModel().getColumn(1).setPreferredWidth(20);
			table.getColumnModel().getColumn(2).setPreferredWidth(100);
			table.getColumnModel().getColumn(3).setPreferredWidth(250);
			table.addMouseListener(new MouseAdapter() {//���ѡ������
				public void mouseClicked(MouseEvent e) {
					/*if(table.getValueAt(table.getSelectedRow(),0)!=null){
						String n = (String)table.getValueAtjTable.getSelectedRow(),0); 
					}
					jtextfield.setText(s);
					repaint();*/
					int n=table.getSelectedRow();//ѡ�б���ڼ��У�0��ʼ
					Line=n;
					textArea_1.setText(xml.Tag_Text.get(n));
				}
			});
			table.addMouseMotionListener(new MouseAdapter(){//���ͣ����ʾ
				public void mouseMoved(MouseEvent e) {
					int row=table.rowAtPoint(e.getPoint());
					int col=table.columnAtPoint(e.getPoint());
					if(row>-1 && col>-1){
						Object value=table.getValueAt(row, col);
						if(null!=value && !"".equals(value))
							table.setToolTipText(value.toString());//������ʾ��Ԫ������
						else
							table.setToolTipText(null);//�ر���ʾ
					}
				}
			});
			scrollPane_2.setViewportView(table);
			textArea.setText(xml.getInfo());
		}
	}
}
class ImageFilter extends FileFilter{//�޶���xml
    public boolean accept(File f){
        if (f.isDirectory()){
            return true;
        }
        String fileName = f.getName();
        String extension=fileName.substring(fileName.lastIndexOf(".") + 1);
        if (extension != null){
            if (extension.toLowerCase().equals("xml"))
                return true;
            else
                return false;
        }
        return false;
    }
    public String getDescription(){
        return "XML File(*.xml)";
    }
}
