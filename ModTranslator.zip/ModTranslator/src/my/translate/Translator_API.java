package my.translate;
import java.awt.Desktop;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.baidu.translate.demo.TransApi;

public class Translator_API {
	private static String en2zh_google(String src){  
		String re=getHTTP("http://translate.google.cn/translate_a/single?client=gtx&dt=t&dj=1&ie=UTF-8&sl=auto&tl=zh_CH&q="+src);
		if(re.startsWith("Error"))  return re;
		String[] res=re.split("\"trans\":\"");
		re="";
		for(int i=1;i<res.length;i++){
			re+=res[i].substring(0,res[i].indexOf("\""));
		}
		return re;
	}
	private static String en2zh_Bing(String src){
		String re=getHTTP("http://api.microsofttranslator.com/v2/Http.svc/Translate?appId=AFC76A66CF4F434ED080D245C30CF1E71C22959C&from=&to=zh&text="+src);
		if(re.startsWith("Error"))  return re;
		String regEx_html="<[^>]+>"; //����HTML��ǩ���������ʽ
        Pattern p_html=Pattern.compile(regEx_html,Pattern.CASE_INSENSITIVE);
        Matcher m_html=p_html.matcher(re);
        re=m_html.replaceAll("");
		return re;
	}
	private static String en2zh_Youdao(String src){
		String re=getHTTP("http://fanyi.youdao.com/translate?&doctype=json&type=EN2ZH_CN&i="+src);
		if(re.startsWith("Error"))  return re;
		String[] res=re.split("\"tgt\":\"");
		re="";
		for(int i=1;i<res.length;i++){
			re+=res[i].substring(0,res[i].indexOf("\""));
		}
		return re;
	}
	private static String en2zh_Baidu(String src){
		TransApi api = new TransApi("20190827000329729","w0akMg7E1ol8HorJzpbr");//APP_ID,SECURITY_KEY
        String re=api.getTransResult(src, "auto", "zh");
        if(re==null)  return "Error:can not connect to api.fanyi.baidu.com";
        String[] res=re.split("\"dst\":\"");
		re="";
		for(int i=1;i<res.length;i++){
			re+=res[i].substring(0,res[i].indexOf("\""));
		}
		return changeCharset(re);
	}
	private static void browse(String url) throws Exception {
        Desktop desktop = Desktop.getDesktop();
        if (Desktop.isDesktopSupported() && desktop.isSupported(Desktop.Action.BROWSE)) {
            URI uri = new URI(url);
            desktop.browse(uri);
        }
    }
	private static String encode(String input) {//��������ַ�������URL����, ��ת��Ϊ%20������ʽ
        if (input == null) return "";
        try {
            return URLEncoder.encode(input.trim(), "utf-8");//�ٶȱ���ȥ�ո�
        } catch (UnsupportedEncodingException e) {
            return "Error:"+e;
        }
    }
	private static String getHTTP(String http){//��ȡHTTP��ҳ��Ϣ
		StringBuilder str=new StringBuilder();//���̣߳���
        try {
            URL url = new URL(http);// ����URL����
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setConnectTimeout(10000); // ������Ӧ��ʱ
            con.setRequestMethod("GET");
            int statusCode = con.getResponseCode();
            if (statusCode != HttpURLConnection.HTTP_OK) {
            	return "Error:ResponseCode="+statusCode;
            }
            
            InputStream in = con.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(in,"UTF-8"));
            String inputLine = null;
            while ((inputLine = reader.readLine()) != null){
            	inputLine=inputLine.trim();
            	str.append(inputLine);
            }
            in.close();
        }catch (MalformedURLException e) {
        	return "Error:"+e;
		}catch (ProtocolException e) {
			return "Error:"+e;
		}catch (UnsupportedEncodingException e) {
			return "Error:"+e;
		}catch (IOException e) {
			return "Error:"+e;
		}
        return str.toString();
	}
	private static String changeCharset(String str){//�����ٶȷ��ص�Unicode�ַ���
		try {
			StringReader reader = new StringReader("key:"+str);
	        Properties props = new Properties();
	        props.load(reader);
	        return props.getProperty("key").replaceAll("[+]", " ");
		} catch (IOException e) {
			return "Error:"+e;
		}
	}
	
	public static String en2zh_Baidu_person(String src,String APP_ID,String SECURITY_KEY){//���˰ٶ�ID
		String temp=encode(src);
		if(src.startsWith("Error")){
			return temp;
		}
		TransApi api = new TransApi(APP_ID,SECURITY_KEY);//APP_ID,SECURITY_KEY
		String re=api.getTransResult(src, "auto", "zh");
		String[] res=re.split("\"dst\":\"");
		re="";
		for(int i=1;i<res.length;i++){
			re+=res[i].substring(0,res[i].indexOf("\""));
		}
		return changeCharset(re);
	}
	public static void getWeb(int platform,String src){//���ط�����ҳ����,��������API���Ӳ�ͬ 
		try {
			switch(platform){//1=Baidu 2=google 3=Youdao 4=Bing
			case 1:browse("https://fanyi.baidu.com/#en/zh/"+encode(src));break;
			case 2:browse("https://translate.google.cn/#view=home&op=translate&sl=auto&tl=zh-CN&text="+encode(src));break;
			case 3:browse("http://fanyi.youdao.com/");break;
			case 4:browse("https://cn.bing.com/translator/");break;
			default:System.out.println("platform id error");break;
			}
		} catch (Exception e) {
			System.out.println("browse failed:"+e);
		}
	}
	public static String getResult(int platform,String src){//Ŀǰֻ����Ӣ�뺺
		String temp=encode(src);
		if(src.startsWith("Error")){
			return temp;
		}
		switch(platform){//1=Baidu 2=google 3=Youdao 4=Bing
		case 1:temp=en2zh_Baidu(temp);break;
		case 2:temp=en2zh_google(temp);break;
		case 3:temp=en2zh_Youdao(temp);break;
		case 4:temp=en2zh_Bing(temp);break;
		default:temp="Error:platform id error!";
		}
		return temp;
	}
}
